using ClassLibrary1.Repo;
using DapperHw.Core.Entities;

namespace DapperHw.UI;

public class ManageReviews
{
    private ReviewRepo _reviewRepo = new ReviewRepo();

    public void AddReview()
    {
        Reviews review = new Reviews();
        Console.WriteLine("Enter review ID:");
        review.Id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter user ID:");
        review.UserId = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter restaurant ID:");
        review.RestaurantId = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter rating:");
        review.Rating = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter comment:");
        review.Comment = Console.ReadLine();
        _reviewRepo.Create(review);
    }

    public void DeleteReview()
    {
        Console.WriteLine("Enter review ID:");
        int id = Convert.ToInt32(Console.ReadLine());
        _reviewRepo.DeleteById(id);
    }

    public void GetReviewById()
    {
        Console.WriteLine("Enter review ID:");
        int id = Convert.ToInt32(Console.ReadLine());
        var review = _reviewRepo.GetById(id).FirstOrDefault();
        if (review != null)
        {
            Console.WriteLine($"Review ID: {review.Id}");
            Console.WriteLine($"User ID: {review.UserId}");
            Console.WriteLine($"Restaurant ID: {review.RestaurantId}");
            Console.WriteLine($"Rating: {review.Rating}");
            Console.WriteLine($"Comment: {review.Comment}");
        }
        else
        {
            Console.WriteLine("Review not found.");
        }
    }

    public void UpdateReview()
    {
        Reviews review = new Reviews();
        Console.WriteLine("Enter review ID:");
        review.Id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter user ID:");
        review.UserId = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter restaurant ID:");
        review.RestaurantId = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter rating:");
        review.Rating = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter comment:");
        review.Comment = Console.ReadLine();
        _reviewRepo.Update(review);
    }

    public void GetAllReviews()
    {
        IEnumerable<Reviews> reviews = _reviewRepo.GetAll();
        foreach (var review in reviews)
        {
            Console.WriteLine($"Review ID: {review.Id}");
            Console.WriteLine($"User ID: {review.UserId}");
            Console.WriteLine($"Restaurant ID: {review.RestaurantId}");
            Console.WriteLine($"Rating: {review.Rating}");
            Console.WriteLine($"Comment: {review.Comment}");
            Console.WriteLine("---");
        }
    }
}