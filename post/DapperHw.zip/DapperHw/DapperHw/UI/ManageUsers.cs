using ClassLibrary1.Repo;
using DapperHw.Core.Entities;

namespace DapperHw.UI;

public class ManageUsers
{
    private UserRepo _UserRepo = new UserRepo();

    public void AddUsers()
    {
        Users users = new Users();
        Console.WriteLine("enter id");
        users.Id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter name");
        users.Name = Console.ReadLine();
        Console.WriteLine("enter location");
        users.Location = Console.ReadLine();
        _UserRepo.Create(users);
    }

    public void DeleteUsers()
    {
        Console.WriteLine("enter id");
        int id = Convert.ToInt32(Console.ReadLine());
        _UserRepo.DeleteById(id);
    }

    public void GetById()
    {
        Console.WriteLine("enter id");
        int id = Convert.ToInt32(Console.ReadLine());
        var user = _UserRepo.GetById(id);
    }

    public void Update()
    {
        Users users = new Users();
        Console.WriteLine("enter id");
        users.Id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter name");
        users.Name = Console.ReadLine();
        Console.WriteLine("enter location");
        users.Location = Console.ReadLine();
        _UserRepo.Update(users);
    }

    public void GetAll()
    {
        IEnumerable<Users> users = _UserRepo.GetAll();
        foreach (var user in users)
        {
            Console.WriteLine(user.Id);
        }
    }
    
}