﻿// See https://aka.ms/new-console-template for more information

using DapperHw.UI;

Console.WriteLine("Hello, World!");

ManageUsers manageUsers = new ManageUsers();

manageUsers.GetAll();

manageUsers.DeleteUsers();