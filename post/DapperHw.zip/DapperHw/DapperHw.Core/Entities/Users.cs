namespace DapperHw.Core.Entities;

public class Users
{
    //a user can have many reviews
    public int Id { get; set; }
    public string? Name { get; set; }
    public string? Location { get; set; }
}