namespace DapperHw.Core.Entities;

public class Reviews
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int RestaurantId { get; set; }
    public int Rating { get; set; }
    public string? Comment { get; set; }
    public Users User { get; set; }
}