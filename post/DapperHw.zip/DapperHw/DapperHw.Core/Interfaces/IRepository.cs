using DapperHw.Core.Entities;

namespace DapperHw.Core.Interfaces;

public interface IRepository<T> where T:class
{
    int Create(T obj);
    int DeleteById(int id);
    IEnumerable<Reviews> GetById(int id);
    int Update(T obj);
    IEnumerable<T> GetAll();
}