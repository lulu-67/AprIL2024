using System.Data;
using ClassLibrary1.Data;
using Dapper;
using DapperHw.Core.Entities;
using DapperHw.Core.Interfaces;

namespace ClassLibrary1.Repo;

public class ReviewRepo : IRepository<Reviews>
{
    private DbConnection _dbConnection = new Data.DbConnection();

    public int Create(Reviews obj)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Execute("INSERT INTO Reviews VALUES(@ID, @USERID, @RESTAURANTID, @RATING, @COMMENT)", obj);
    }

    public int DeleteById(int id)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Execute("DELETE FROM Reviews WHERE Id = @id", new { id = id });
    }

    public IEnumerable<Reviews> GetById(int id)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Query<Reviews>("SELECT Id, UserId, RestaurantId, Rating, Comment FROM Reviews WHERE Id = @id", new { id = id });
    }

    public int Update(Reviews obj)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Execute("UPDATE Reviews SET UserId = @UserId, RestaurantId = @RestaurantId, Rating = @Rating, Comment = @Comment WHERE Id = @Id", obj);
    }

    public IEnumerable<Reviews> GetAll()
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Query<Reviews>("SELECT Id, UserId, RestaurantId, Rating, Comment FROM Reviews");
    }
}