
using System.Data;
using ClassLibrary1.Data;
using Dapper;
using DapperHw.Core.Entities;
using DapperHw.Core.Interfaces;


namespace ClassLibrary1.Repo;

public class UserRepo : IRepository<Users>
{
    private DbConnection _dbConnection = new Data.DbConnection();
    public int Create(Users obj)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Execute("INSERT INTO USERS VALUES(@ID, @NAME, @LOCATION)", obj);
    }

    public int DeleteById(int id)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Execute("DELETE FROM Users where Id = @id", id);
    }

    public IEnumerable<Reviews> GetById(int id)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.QuerySingleOrDefault<IEnumerable<Reviews>>("select id, name, location where id =@id",
            new { id = id });
    }

    public int Update(Users obj)
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Execute("Update Users set id =@id, name = @name, location = @location", obj);
    }

    public IEnumerable<Users> GetAll()
    {
        IDbConnection conn = _dbConnection.GetConnection();
        return conn.Query<Users>("select id, name, location from users");
    }
}