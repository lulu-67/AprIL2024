using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace ClassLibrary1.Data;

public class DbConnection
{
    public SqlConnection GetConnection()
    {
        var conn = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json").Build()
            .GetConnectionString("DapperHwDb");
        return new SqlConnection(conn);
    }
}