﻿using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ApplicationCore.RepositoryContract;
using Infrastructure.Data;


namespace Infrastructure.Repository
{
    public class BaseRepository<T> : IRepository<T> where T : class
    {
        private readonly EcommerceDbContext _context;
        public BaseRepository(EcommerceDbContext context) { _context = context; }
        public int Delete(int id)
        {
            var i = GetById(id);
            if (i != null)
            {
                _context.Remove(i);
                return _context.SaveChanges();
            }
            return 0;
        }

        public IEnumerable<T> Filter(Func<T, bool> predicate)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetAll()
        {
            return _context.Set<T>().ToList();

        }

        public T GetById(int id)
        {
            return _context.Set<T>().Find(id);
        }

        public int Insert(T entity)
        {
            _context.Set<T>().Add(entity);
            return _context.SaveChanges();
        }

        public int Update(T entity)
        {
            _context.Set<T>().Entry(entity).State = EntityState.Modified;
            return _context.SaveChanges();
        }
    }
}
