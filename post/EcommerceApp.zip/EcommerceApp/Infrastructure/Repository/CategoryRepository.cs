﻿using ApplicationCore.Entities;
using ApplicationCore.RepositoryContract;
using Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Repository
{
    public class CategoryRepository : ICategoryRepository, BaseRepository<Category>
    {
        public CategoryRepository(EcommerceDbContext context) : base(context)
        {
        }
    }
}
